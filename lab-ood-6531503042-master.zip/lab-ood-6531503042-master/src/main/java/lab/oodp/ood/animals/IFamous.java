package lab.oodp.ood.animals;

 /* Represents something famous
 */
public interface IFamous {

     /* Gets a description of what the species is famous for.
     */
    public String famous();

    public String getFamousfor();

    /**
     * Gets the name of a famous member of the species.
     */
    public String getFamousName();
}