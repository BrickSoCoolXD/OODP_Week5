package lab.oodp.ood.animals;

/**
 * Represents a Horse.
 */
public class Horse implements IAnimal, IFamous {
    private String name;
    private int legCount;

    public Horse(String name, int legCount) {
        this.name = name;
        this.legCount = legCount;
    }

    public String sayHello() {
        return "neigh";
    }
    @Override
    public boolean isMammal() {
        return true;
    }

    public String myName() {
        return name + " the horse";
    }

    public int legCount() {
        return legCount;
    }

    public String getFamousName() {
        return "PharLap";
    }

    @Override
    public String famous() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getFamousfor() {
        // TODO Auto-generated method stub
        return null;
    }
}