package lab.oodp.ood.animals;

/**
 * Represents a Dog.
 */
public class Dog implements IAnimal {
    private String name;
    private int legCount;

    
    public Dog(String name, int legCount) {
        this.name = name;
        this.legCount = legCount;
    }

    public String sayHello() {
        return "woof woof";
    }
    @Override
    public boolean isMammal() {
        return true;
    }

    public String myName() {
        return name + " the dog";
    }

    public int legCount() {
        return legCount;
    }
}