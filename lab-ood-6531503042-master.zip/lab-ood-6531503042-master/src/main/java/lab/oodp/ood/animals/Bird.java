package lab.oodp.ood.animals;

/**
 * Represents a Bird.
 */
public class Bird implements IAnimal {
    private String name;
    private int legCount;

    public Bird(String name, int legCount) {
        this.name = name;
        this.legCount = legCount;
    }

    public String sayHello() {
        return "tweet tweet";
    }
    @Override
    public boolean isMammal() {
        return false;
    }

    public String myName() {
        return name + " the bird";
    }

    public int legCount() {
        return legCount;
    }
}